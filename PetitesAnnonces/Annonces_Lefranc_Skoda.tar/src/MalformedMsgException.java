public class MalformedMsgException extends Exception{
	public MalformedMsgException(){
	}
}
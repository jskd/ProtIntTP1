#**************************************************#
# Name : Section 1 et 2 du TP
# Version : 0.0.1
# Auteurs : 
#**************************************************#

MAKEFILE RULES :
----------------------------------------------------
 - make : Compile dans bin/
 - make runserv : Execute le serveur
 - make runcli ip=0.0.0.0 : Execute le client, ip du serveur à spécifier
 - make tar : Archive le projet
 - make clean : Supprime les .class
----------------------------------------------------